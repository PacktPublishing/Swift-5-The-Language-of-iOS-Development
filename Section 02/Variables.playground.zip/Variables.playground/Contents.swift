import UIKit

var user = "Mark Lassoff"
var age = 45
var gpa = 3.857
var result = 2 * 87 + 1
age = 46

var middleName = "Adam"

var name1="Tom" ; var name2 = "Bob"
print( name2 )







