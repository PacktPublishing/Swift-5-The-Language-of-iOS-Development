import UIKit

var age:Int = 45
var taxRate:Float = 0.055
var name:String = "Mark Lassoff"
var isPlaying:Bool = true
var precise:Double = 0.00001234
var age2:Float = 45


print ( age )
print ( age2 )
print ( taxRate )
print ( name )






