import UIKit

var str = "Hello, playground"
print ( str )

var poem = """
Roses are red
Violets are blue
Programming is fun
For me and for you
"""

print ( poem )

let first = "Mark"
let last = "Lassoff"

var fullName = first + " " + last

print (fullName)

var announcement = "Your gpa is :"
announcement += " 3.44"
print (announcement)

