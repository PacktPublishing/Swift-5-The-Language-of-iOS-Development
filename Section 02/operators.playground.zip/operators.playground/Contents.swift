import UIKit

var value1 = 125
var value2 = 75

print (value1 + value2)
print (value1 - value2)
print (value1 * value2)
print (value1 / value2)

var x = 10; var y = 5

print (x % y)
print ((x-1) % y)

value1 += 5
print( value1 )

value1 -= 10
print(value1)

value2 *= 2
print (value2 )

