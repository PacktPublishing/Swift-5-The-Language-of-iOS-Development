import UIKit

let NAME = "Mark Lassoff"
let RESULT = 45 + 45
print( NAME )
print( RESULT )




