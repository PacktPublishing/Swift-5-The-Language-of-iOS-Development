import UIKit

/*
var x  = 1

while ( x < 11){
    print (x)
    x += 1
}


var y = 0

while ( y < 10000){
    print (y)
    y += 150
}


var score = 50

while (score > 51) {
    print ("Hey there")
    score -= 1
}
*/


var counter = 0

while (counter > -1){
    print (counter)
    counter += 1
}



