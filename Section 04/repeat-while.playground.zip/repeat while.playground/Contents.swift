import UIKit


var value = 10

repeat {
   print (value)
   value -= 1
} while value > 0


