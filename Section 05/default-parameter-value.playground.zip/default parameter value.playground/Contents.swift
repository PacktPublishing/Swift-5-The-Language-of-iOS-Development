import UIKit

func areaOfRect (length:Int=1, height:Int=1) -> Int {
    return length * height
}

print ( areaOfRect(length:12,height:12) )
print ( areaOfRect() )
