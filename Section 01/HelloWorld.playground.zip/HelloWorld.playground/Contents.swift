import UIKit

var message = "Hello World from Mark"
print (message)
print ("Welcome to the Swift 5 course.")
print (9 * 5)
var value = 9 * 5
print (value)
